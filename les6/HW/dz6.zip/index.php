<?php
header("Content-type: text/html; charset=utf-8");
require_once("settings.php");

function max_img($gallery)
{
	$result = 0;
	foreach($gallery as $img)
	{
		if (($img == '.')||($img == '..'))
		{
			continue;
		}
		

		$img_num = img_num($img);
		if ($img_num>$result) $result = $img_num;
	}	
	return $result;
}

function create_thumb($src)
{
	$source=$src; //наш исходник

	$img_num = img_num($src);
	
	$dest = THUMB_PATH . "/img" . $img_num . ".jpg";
	
	$height=200; //параметр высоты превью
	$width=200; //параметр ширины превью
	$rgb=0xffffff; //цвет заливки несоответствия
	$size = getimagesize($source);//узнаем размеры картинки (дает нам масив size)
	$format = strtolower(substr($size['mime'], strpos($size['mime'], '/')+1)); //определяем тип файла
	$icfunc = "imagecreatefrom" . $format;   //определение функции соответственно типу файла
	if (!function_exists($icfunc)) return false;  //если нет такой функции прекращаем работу скрипта
	$x_ratio = $width / $size[0]; //пропорция ширины будущего превью
	$y_ratio = $height / $size[1]; //пропорция высоты будущего превью
	$ratio       = min($x_ratio, $y_ratio);
	$use_x_ratio = ($x_ratio == $ratio); //соотношения ширины к высоте
	$new_width   = $use_x_ratio  ? $width  : floor($size[0] * $ratio); //ширина превью 
	$new_height  = !$use_x_ratio ? $height : floor($size[1] * $ratio); //высота превью
	$new_left    = $use_x_ratio  ? 0 : floor(($width - $new_width) / 2); //расхождение с заданными параметрами по ширине
	$new_top     = !$use_x_ratio ? 0 : floor(($height - $new_height) / 2); //расхождение с заданными параметрами по высоте
	$img = imagecreatetruecolor($width,$height); //создаем вспомогательное изображение пропорциональное превью
	imagefill($img, 0, 0, $rgb); //заливаем его…
	$photo = $icfunc($source); //достаем наш исходник
	imagecopyresampled($img, $photo, $new_left, $new_top, 0, 0, $new_width, $new_height, $size[0], $size[1]); //копируем на него нашу превью с учетом расхождений
	imagejpeg($img, $dest); //выводим результат (превью картинки)
	// Очищаем память после выполнения скрипта
	imagedestroy($img);
	imagedestroy($photo);
}

function img_num($path)
{
    $name = pathinfo($path, PATHINFO_FILENAME);
    $num = (int) substr($name,3);
    return $num;
}

function write_description($num,$text)
{
    $filename = DESC_PATH . '/' . "img{$num}.txt";
    $f = fopen($filename,"w"); // перезаписываем не разбираясь
    fwrite($f,$text);
    fclose($f);
}

function delete_file($num)
{
    $filename = IMG_PATH . "/img{$num}.jpg";
    $thumbname = THUMB_PATH . "/img{$num}.jpg";
    $descname = DESC_PATH . "/img{$num}.txt";

    @unlink($filename);
    @unlink($thumbname);
    @unlink($descname);

}



function img_up($num)
{
    $filename = IMG_PATH . "/img{$num}.jpg";
    $thumbname = THUMB_PATH . "/img{$num}.jpg";
    $descname = DESC_PATH . "/img{$num}.txt";

    $up_num = $num - 1;

    $upfilename = IMG_PATH . "/img{$up_num}.jpg";
    $upthumbname = THUMB_PATH . "/img{$up_num}.jpg";
    $updescname = DESC_PATH . "/img{$up_num}.txt";


    // backing up

    $tmpfilename = IMG_PATH . "/tmp_img.jpg";
    $tmpthumbname = THUMB_PATH . "/tmp_img.jpg";
    $tmpdescname = DESC_PATH . "/tmp_desc.txt";

    rename($filename,$tmpfilename);
    if (file_exists($thumbname))
    {
        rename($thumbname,$tmpthumbname);
    }
    if (file_exists($descname))
    {
        rename($descname,$tmpdescname);
    }

    // перемещение на освободившееся место файла сверху

    rename($upfilename,$filename);
    if (file_exists($upthumbname))
    {
        rename($upthumbname,$thumbname);
    }
    if (file_exists($updescname))
    {
        rename($updescname,$descname);
    }

    // и занимаем нужное место отбекапленным файлом
    rename($tmpfilename,$upfilename);
    if (file_exists($tmpthumbname))
    {
        rename($tmpthumbname,$upthumbname);
    }
    if (file_exists($tmpdescname))
    {
        rename($tmpdescname,$updescname);
    }

}

function img_down($num)
{
    $filename = IMG_PATH . "/img{$num}.jpg";
    $thumbname = THUMB_PATH . "/img{$num}.jpg";
    $descname = DESC_PATH . "/img{$num}.txt";

    $down_num = $num + 1;

    $downfilename = IMG_PATH . "/img{$down_num}.jpg";
    $downthumbname = THUMB_PATH . "/img{$down_num}.jpg";
    $downdescname = DESC_PATH . "/img{$down_num}.txt";


    // backing up

    $tmpfilename = IMG_PATH . "/tmp_img.jpg";
    $tmpthumbname = THUMB_PATH . "/tmp_img.jpg";
    $tmpdescname = DESC_PATH . "/tmp_desc.txt";

    rename($filename,$tmpfilename);
    if (file_exists($thumbname))
    {
        rename($thumbname,$tmpthumbname);
    }
    if (file_exists($descname))
    {
        rename($descname,$tmpdescname);
    }

    // перемещение на освободившееся место файла сверху

    rename($downfilename,$filename);
    if (file_exists($downthumbname))
    {
        rename($downthumbname,$thumbname);
    }
    if (file_exists($downdescname))
    {
        rename($downdescname,$descname);
    }

    // и занимаем нужное место отбекапленным файлом
    rename($tmpfilename,$downfilename);
    if (file_exists($tmpthumbname))
    {
        rename($tmpthumbname,$downthumbname);
    }
    if (file_exists($tmpdescname))
    {
        rename($tmpdescname,$downdescname);
    }

}

$gallery_img = scandir(IMG_PATH);
$error = array();
if (isset($_POST['action']))
{
	if ($_POST['action']=='upload')
	{
        if ($_FILES['upload_file']['error']==UPLOAD_ERR_OK)
        {
            $uploaddir = IMG_PATH;
            $next_num = max_img($gallery_img) + 1;
            $uploadfile = $uploaddir . "/img" . $next_num . ".jpg";
            $imgdata = getimagesize($_FILES['upload_file']['tmp_name']);
            if (!in_array($imgdata['mime'], array('image/jpeg', 'image/pjpeg'))) {
                //Если это не файл изображения, то лучше показать ошибку и не перемещать изображение на его постоянное место. Временный файл будет удален автоматически.
                $error[] = "Не тот тип файла";
            } else {
                if (move_uploaded_file($_FILES['upload_file']['tmp_name'], $uploadfile)) {
                    create_thumb($uploadfile);
                    if (isset($_POST['description']))
                    {
                        if ($_POST['description']!='')
                        {
                            write_description(img_num($uploadfile),$_POST['description']); // пишем описание
                        }
                    }
                    header('Location: index.php?success');
                } else {
                    $error[] = "Ошибка при загрузке файла";
                }
            }
        }
        else
        {
            $error[] = "Файл не был загружен";
        }
	}

    // удаление
    if ($_POST['action']=='delete')
    {
        $file_num = $_POST['number'];
        delete_file($file_num);
        header('Location: index.php?success');
    }

    //вниз
    if ($_POST['action']=='image_down')
    {
        $file_num = $_POST['number'];
        img_down($file_num);
        header('Location: index.php?success');
    }

    // вверх
    if ($_POST['action']=='image_up')
    {
        $file_num = $_POST['number'];
        img_up($file_num);
        header('Location: index.php?success');
    }


}


?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Галерея</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/font-awesome.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
  <div class="container">

    <h1>Галерея изображений</h1>
      <?php
      if (isset($_GET['success']))
      {
         ?>
      <div class="alert alert-success">Успешно!</div>
      <?php
      }
      ?>
      <?php
      if (count($error))
      {
          ?>
          <div class="alert alert-danger">


      <?php
          foreach ($error as $e)
          {
              echo "<strong>Ошибка!</strong> {$e}";
          }
      ?>
          </div>
              <?php
      }
      ?>
      <div class="row">
          <div class="col-md-4">
              <h2>Загрузка изображения</h2>
              <form action="index.php" enctype="multipart/form-data" method="POST">
                  <input type="hidden" name="action" value="upload"/>
                  <input type="text" name="description" value="" placeholder="Описание"/>
                  <br/>
                  <input type="file" name="upload_file"/>
                  <button type="submit" class="btn btn-primary"><i class="fa fa-upload"></i> Загрузить</button>
              </form>
          </div>
          <div class="col-md-8">
    <?php
        $first_image = true;
        foreach($gallery_img as $img)
        {

            if (($img == '.')||($img == '..'))
            {
                continue;
            }
            if ($first_image === false)
            {
                echo "<form style=\"display:inline\" action=\"index.php\" method=\"POST\"><input type=\"hidden\" name=\"action\" value=\"image_down\"/><input type=\"hidden\" name=\"number\" value=\"{$img_num}\"/><button type=\"submit\" class=\"btn btn-round\"><i class=\"fa fa-arrow-down\"></i></button></form>";
                echo "<br/>";
            }


            $img_num = img_num($img);
            $thumb_path = THUMB_PATH . "/" . $img;

            echo "<a href=\"photo.php?id={$img_num}\"><img src=\"{$thumb_path}?".time()."\" /></a>&nbsp;"; // time для кеша
            echo "<form style=\"display:inline\" action=\"index.php\" method=\"POST\"><input type=\"hidden\" name=\"action\" value=\"delete\"/><input type=\"hidden\" name=\"number\" value=\"{$img_num}\"/><button type=\"submit\" class=\"btn btn-round\"><i class=\"fa fa-times\"></i></button></form>"; // кнопка удаления
            if ($first_image === false) echo "<form style=\"display:inline\" action=\"index.php\" method=\"POST\"><input type=\"hidden\" name=\"action\" value=\"image_up\"/><input type=\"hidden\" name=\"number\" value=\"{$img_num}\"/><button type=\"submit\" class=\"btn btn-round\"><i class=\"fa fa-arrow-up\"></i></button></form>"; // наверх

            $first_image = false;
        }
    ?>

          </div>
      </div>
  </div>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>