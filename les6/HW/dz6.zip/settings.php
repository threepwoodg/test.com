<?php
/**
 * Created by PhpStorm.
 * User: dusty
 * Date: 31.10.15
 * Time: 13:18
 */
define("IMG_PATH","./img/gallery");
define("THUMB_PATH","./img/thumb");
define("DESC_PATH","./img/desc");