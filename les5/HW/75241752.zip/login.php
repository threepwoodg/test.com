<?php
include("const.php");
$err=array();//массив ошибок
$login='';
if (isset($_POST['login']) && isset($_POST['password']))
{
    // проверка введенных данных
    if(!preg_match("/^[a-zA-Z0-9_]+$/",$_POST['login'])) $err[] = "Логин может состоять только из букв английского алфавита и цифр";
    if(strlen($_POST['login']) < 4 or strlen($_POST['login']) > 20) $err[] = "Логин должен быть не меньше 4-х символов и не больше 20";
    if(strlen($_POST['password'])<8) $err[] = "Пароль должен быть не короче 8 символов";
    $login=$_POST['login'];
    if(count($err)==0){
        session_start();
        $_SESSION['hash'] = md5($_POST['login'].$_POST['password']); // Лучше хранить случайную строку и id пользователя и проверять их на стороне сервера, плюс можно проверять IP
        setcookie("username",$_POST['login'],time()+YEAR);
        if (isset($_POST['remember'])) setcookie("hash",$_SESSION['hash'],time()+WEEK); //запомнить на неделю
        else setcookie("hash","",time()-3600); // удалить куку, если она была 
        if (isset($_COOKIE['lastpage'])){
            header("Location: {$_COOKIE['lastpage']}.php");
            die();
        }
        header("Location: index.php");
        die();
    }
}
?>
<html xmlns="http://www.w3.org/1999/xhtml" lang="ru" xml:lang="ru">
<head>
    <meta http-equiv="Content-type" content="text/html; charset=utf-8" />
    <link href="css/<?php echo $style_file?>" rel="stylesheet" type="text/css" />
    <title>Домашнее задание. Урок 5</title>
</head>
    <body>
        <h1>Авторизация</h1>
        <p><span class="red"><?php echo count($err>0) ? implode("<br />", $err) : ""?></span></p>
        <form action="login.php" method="post">
            Имя пользователя: <input type="text" name="login" value="<?php echo $login?>" /><br/>
            Пароль: <input type="password" name="password"/><br/>
            <input type="checkbox" name="remember" value="1"/><span>Запомни меня на неделю.</span><br/>
            <input type="submit" value="Войти"/>
        </form>
    </body>
</html>