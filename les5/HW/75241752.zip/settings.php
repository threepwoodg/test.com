<?php
include_once("auth.php");
if(isset($_POST['style'])){
	switch ($_POST['style']){
		case BLUE:
			setcookie("style",BLUE,time()+LONGTIME); //стиль можно хранить долго
			break;
		case PINK:
			setcookie("style",PINK,time()+LONGTIME); 
			break;
		default:
			setcookie("style",STANDART,time()+LONGTIME); 
	}
	header("Location: index.php");
	die();
}
?>
<html xmlns="http://www.w3.org/1999/xhtml" lang="ru" xml:lang="ru">
<head>
    <meta http-equiv="Content-type" content="text/html; charset=utf-8" />
    <link href="css/<?php echo $style_file?>" rel="stylesheet" type="text/css" />
    <title>Домашнее задание. Урок 5</title>
</head>
	<body>
	<h1>Выбирай тему:</h1>
	<form method="post">
		<select name="style">
			<option value="<?php echo STANDART?>"<?php echo $style==STANDART ? " selected" : ""?>>Стандартная</option>
			<option value="<?php echo BLUE?>"<?php echo $style==BLUE ? " selected" : ""?>>Синяя</option>
			<option value="<?php echo PINK?>"<?php echo $style==PINK ? " selected" : ""?>>Розовая</option>
		</select>
		<input type="submit" value="Выбрать" />
	</form>
	<p>
		<a href="index.php">Главная</a><br/>
		<a href="a.php">Страница A</a><br/>
		<a href="b.php">Страница B</a><br/>
		<a href="logout.php">Выход</a><br/>
	</p>
	</body>
</html>