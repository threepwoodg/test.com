<?php
session_start();
include("const.php");
if ((!isset($_SESSION['hash']))&&(!isset($_COOKIE['hash'])))
{
    header("Location: login.php");
    die();
}
if ((!isset($_SESSION['hash']))&&(isset($_COOKIE['hash'])))
{
    $_SESSION['hash'] = $_COOKIE['hash']; 
    if (isset($_COOKIE['lastpage']))
    {
        header("Location: {$_COOKIE['lastpage']}.php");
        die();
    }
}
$username = $_COOKIE['username'];
?>