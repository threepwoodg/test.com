<?php
define("STANDART","standart");
define("BLUE","blue");
define("PINK","pink");
define("LONGTIME",3600*24*365*5);
define("WEEK",3600*24*7);
define("YEAR",3600*24*365);
if(isset($_COOKIE['style'])){
	$style_file="{$_COOKIE['style']}.css";
	$style=$_COOKIE['style']; //для удобства
	setcookie("style",$style,time()+LONGTIME); // обновим срок хранения куки
}
else{
	$style=STANDART;
	$style_file=STANDART.".css";
} 
?>