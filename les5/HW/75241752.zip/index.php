<?php
include_once("auth.php");
setcookie("lastpage","index",time()+YEAR);
?>
<html xmlns="http://www.w3.org/1999/xhtml" lang="ru" xml:lang="ru">
<head>
    <meta http-equiv="Content-type" content="text/html; charset=utf-8" />
    <link href="css/<?php echo $style_file?>" rel="stylesheet" type="text/css" />
    <title>Домашнее задание. Урок 5</title>
</head>
	<body>
	<h1>Главная</h1>
	<h3><?php echo "Привет, {$username}!!<br />";?></h3>
	<p>
		<a href="a.php">Страница A</a><br/>
		<a href="b.php">Страница B</a><br/>
		<a href="settings.php">Настройки</a><br/>
		<a href="logout.php">Выход</a><br/>
	</p>
	</body>
</html>